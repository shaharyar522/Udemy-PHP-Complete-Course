

<h1>
    <?php echo $title; ?>




</h1>

<h2><?php echo $message; ?></h2>