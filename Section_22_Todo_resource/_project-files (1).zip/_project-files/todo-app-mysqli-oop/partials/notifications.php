<!-- Notification Container -->
<div class="notification-container">
    <div class="notification success">
        <!-- Success message will go here -->
    </div>
</div>
