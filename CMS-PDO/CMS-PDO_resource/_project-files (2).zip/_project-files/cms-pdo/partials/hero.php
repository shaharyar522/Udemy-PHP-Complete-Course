<!-- Header Section -->
<header class="bg-dark text-white py-5">
    <div class="container">
        <h1 class="display-4">Welcome to the CMS PDO System</h1>
        <p class="lead">
            Sharing insights, ideas, and stories.
        </p>
    </div>
</header>