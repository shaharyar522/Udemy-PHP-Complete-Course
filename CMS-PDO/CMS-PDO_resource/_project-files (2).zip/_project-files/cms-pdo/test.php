<?php


$error = "this is an error";


echo strpos($error, 'error');