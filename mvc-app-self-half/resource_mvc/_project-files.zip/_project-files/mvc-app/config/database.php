<?php

return [
    'host'     => 'localhost',
    'database' => 'mvc_app_db',
    'username' => 'root',
    'password' => '',
    'port'     => 3306,
    'chartset' => 'utf8mb4'
];



