<?php


$message = "HELLO";


